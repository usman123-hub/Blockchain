import pandas as pd
import firebase_admin
from firebase_admin import credentials, db
from web3 import Web3
from solcx import compile_source, install_solc, get_solc_version
from PyQt5.QtWidgets import QApplication, QMessageBox

# Install Solidity compiler
def install_solidity_compiler(version='0.8.19'):
    try:
        install_solc(version)
        installed_version = get_solc_version()
        if str(installed_version) == version:
            print(f"Successfully installed Solidity compiler version {version}.")
        else:
            print(f"Installed version does not match requested version. Installed: {installed_version}, Requested: {version}.")
    except Exception as e:
        print(f"Error installing Solidity compiler: {e}")

def initialize_firebase():
    try:
        cred = credentials.Certificate('E:/blockchain/blockchain-a6620-firebase-adminsdk-71v72-d7c6b887bb.json')
        firebase_admin.initialize_app(cred, {
            'databaseURL': 'https://blockchain-a6620-default-rtdb.firebaseio.com/'
        })
    except Exception as e:
        print(f"Error initializing Firebase: {e}")

def send_to_firebase(data):
    try:
        ref = db.reference('patients')
        ref.push(data)
    except Exception as e:
        print(f"Error sending data to Firebase: {e}")

def initialize_web3():
    try:
        w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))  # Ensure this URL matches your Ganache setup
        if not w3.is_connected():
            raise ConnectionError("Failed to connect to Ethereum node.")
        print("Connected to Ethereum node.")
        return w3
    except Exception as e:
        print(f"Error initializing Web3: {e}")
        return None

def compile_and_deploy_contract(w3):
    try:
        # Ensure the Solidity compiler is installed
        install_solidity_compiler('0.8.19')

        solidity_code = '''
        pragma solidity ^0.8.0;

        contract PatientData {
            struct Patient {
                string patient_id;
                uint heart_beat;
                uint temperature;
            }

            mapping(string => Patient) public patients;

            function storePatientData(
                string memory _patient_id,
                uint _heart_beat,
                uint _temperature
            ) public {
                patients[_patient_id] = Patient(_patient_id, _heart_beat, _temperature);
            }
        }
        '''

        # Compile Solidity code
        compiled_sol = compile_source(solidity_code, solc_version='0.8.19')
        contract_interface = compiled_sol['<stdin>:PatientData']
        contract = w3.eth.contract(abi=contract_interface['abi'], bytecode=contract_interface['bin'])

        # Deploy the contract using the first account from Ganache
        account = w3.eth.accounts[0]
        tx_hash = contract.constructor().transact({'from': account})
        tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        contract_address = tx_receipt.contractAddress

        print(f"Contract deployed at address: {contract_address}")
        return contract, contract_address
    except Exception as e:
        print(f"Error compiling or deploying contract: {e}")
        return None, None

def read_patient_data_from_csv(file_path, num_rows=20):
    try:
        df = pd.read_csv(file_path, nrows=num_rows)
        data_list = df.to_dict(orient='records')
        return data_list
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return []

def show_alert(message):
    app = QApplication.instance() or QApplication([])  # Ensure QApplication instance
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Warning)
    msg.setText(message)
    msg.setWindowTitle("Alert")
    msg.exec_()

def main():
    # Initialize Firebase
    initialize_firebase()

    # Initialize Ethereum Web3
    w3 = initialize_web3()
    if w3 is None:
        return

    # Compile and deploy the contract
    contract, contract_address = compile_and_deploy_contract(w3)
    if contract is None or contract_address is None:
        return

    # Read patient data from CSV, limiting to 20 rows
    file_path = 'patient_data.csv'  # Update this path
    data_list = read_patient_data_from_csv(file_path, num_rows=20)

    # Send data to Firebase and store on blockchain
    for data in data_list:
        try:
            # Log the data
            print(f"Processing data: {data}")

            # Ensure data types are correct
            patient_id = str(data.get('Patient_ID'))  # Update key if necessary
            heart_beat = int(data.get('Heart_Rate', 0))  # Default to 0 if not present
            temperature = float(data.get('Temperature', 0))  # Use float for temperature

            # Check temperature and show alert if above 90
            if temperature > 90:
                show_alert(f"Alert: Patient {patient_id} has a high temperature of {temperature:.2f}°C. Potential fever detected!")

            # Send data to Firebase
            send_to_firebase(data)

            # Store data on blockchain
            contract_instance = w3.eth.contract(address=contract_address, abi=contract.abi)
            account = w3.eth.accounts[0]

            # Store patient data on the blockchain
            tx_hash = contract_instance.functions.storePatientData(
                patient_id,
                heart_beat,
                temperature
            ).transact({'from': account})
            
            w3.eth.wait_for_transaction_receipt(tx_hash)
            print(f"Patient data for {patient_id} sent to Firebase and stored on blockchain.")
        except Exception as e:
            print(f"Error storing data on blockchain: {e}")

if __name__ == "__main__":
    main()
